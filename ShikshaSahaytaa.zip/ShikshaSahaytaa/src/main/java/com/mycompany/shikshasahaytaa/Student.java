/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.shikshasahaytaa;

import java.io.Serializable;



/**
 *
 * @author ASUS
 */

public class Student implements Serializable
{   
    private int id;
    private String name;
    private String password;
    private String gender;
    private String email;
    private String mobile;     
    private String date;
    private String city;
    private String address;
    private String age;
    private String school;
    private String income;     
    private String occupation;
    private String status; 
public Student()
{

}

public Student(String name, String password ,String gender,String email ,String mobile ,String date, String city ,String address,String age ,String school ,String income ,String occupation)
{
  this.name=name;
  this.password=password;
  this.gender=gender;
  this.email=email;
  this.mobile=mobile;
  this.date=date;
  this.city=city;
  this.address=address;
  this.age=age;
  this.school=school;
  this.income=income;
  this.occupation=occupation;
  
}


        
public Student(int id ,String name, String password ,String gender,String email ,String mobile ,String date ,String city, String address ,String age,String school ,String income ,String occupation ,String status)
{
  this.id=id;
  this.name=name;
  this.password=password;
  this.gender=gender;
  this.email=email;
  this.mobile=mobile;
  this.date=date;
  this.city=city;
  this.address=address;
  this.age=age;
  this.school=school;
  this.income=income;
  this.occupation=occupation;
  this.status = status;
}
public int getID()
{
return id;
}
public String getName()
{
return name;
}
public String getPassword()
{
return password;
}
public String getGender()
{
return gender;
}
public String getEmail()
{
return email;
}
public String getMobile()
{
return mobile;
}
public String getDate()
{
return date;
}
public String getCity()
{
return city;
}
public String getAddress()
{
return address;
}
public String getAge()
{
return age;
}
public String getSchool()
{
return school;
}
public String getIncome()
{
return income;
}
public String getOccupation()
{
return occupation;
}
public String getStatus()
{
return status;
}
public String setStatus(String status)
{
this.status=status;
        return null;
}
}