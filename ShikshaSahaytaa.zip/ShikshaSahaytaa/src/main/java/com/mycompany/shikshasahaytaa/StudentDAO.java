/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.shikshasahaytaa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




/**
 *
 * @author ASUS
 */
public class StudentDAO {
  public static final String url ="jdbc:mysql://localhost:3306/Userdb";
  public static final String username="root";
  public static final String password="Mayuri@17";
  public static Connection getConnection(){
      Connection con =null;
    try
    {
      Class.forName("com.mysql.cj.jdbc.Driver");
      con=DriverManager.getConnection(url,username,password);
    }
    catch(Exception e){
    e.printStackTrace();
    }        
    return con;
  }
  
public static boolean insertStudent( Student student ) {
   boolean status =false;
   Connection con =null;
   PreparedStatement ps = null;
  try
  {
   con=getConnection();
   String query="INSERT INTO Student (name ,password ,gender ,email ,mobile ,date ,city ,address ,age ,school ,income ,occupation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
   ps=con.prepareStatement(query);
   ps.setString(1,student.getName());
   ps.setString(2,student.getPassword());
   ps.setString(3,student.getGender());
   ps.setString(4,student.getEmail());
   ps.setString(5,student.getMobile());
   ps.setString(6,student.getDate());
   ps.setString(7,student.getCity());
   ps.setString(8,student.getAddress());
   ps.setString(9,student.getAge());
   ps.setString(10,student.getSchool());
   ps.setString(11,student.getIncome());
   ps.setString(12,student.getOccupation());
   int rowInserted =ps.executeUpdate();
   status =rowInserted>0;
   con.close();
  }
  catch(Exception e)
  {
      
    e.printStackTrace();
  }
  
  return status;
  }



public static Student loginStudent(String name,String password)
   {
       Student student=null;
       Connection con=null;
       try{
       con=getConnection();
       String query="select  * from student where name=? and password=?";
       PreparedStatement ps=con.prepareStatement(query);
       ps.setString(1,name);
       ps.setString(2, password);
       ResultSet rs=ps.executeQuery();
       if(rs.next()){
         student=new Student(rs.getInt("id"),
         rs.getString("name"),
         rs.getString("password"), 
         rs.getString("gender"),
         rs.getString("email"),
         rs.getString("mobile"),
         rs.getString("date"),
         rs.getString("city"), 
         rs.getString("address"),
         rs.getString("age"),
         rs.getString("school"),
         rs.getString("income"),
         rs.getString("occupation"),
         rs.getString("status"));
       }
       }
         catch(Exception e){
           e.printStackTrace();
         }
         return student;
       } 




public static Student getStudentById(int id)
   {
       Student student=null;
       Connection con=null;
       
       try{
       con=getConnection();
       String query="select * from student where id=?";
       PreparedStatement ps=con.prepareStatement(query);
       ps.setInt(1,id);
       
       ResultSet rs=ps.executeQuery();
       if(rs.next()){
         student=new Student(rs.getInt("id"),
         rs.getString("name"),
         rs.getString("password"), 
         rs.getString("gender"),
         rs.getString("email"),
         rs.getString("mobile"),
         rs.getString("date"),
         rs.getString("city"), 
         rs.getString("address"),
         rs.getString("age"),
         rs.getString("school"),
         rs.getString("income"),
         rs.getString("occupation"),
         rs.getString("status"));
       }
       }
         catch(Exception e){
           e.printStackTrace();
         }
         return student;
       }

   public static boolean updateStudent(int oldid, int id,String name, String password ,String gender,String email ,String mobile ,String date ,String city, String address ,String age,String school ,String income ,String occupation)
   {
 Connection con = null;
 PreparedStatement ps = null;
 boolean status = false;
 try {
 con=getConnection();


 String query = "UPDATE student SET id=?, name=? ,password=? ,gender=? ,email=? ,mobile=? ,date=? ,city=? ,address=? ,age=? ,school=? ,income=? ,occupation=? WHERE id=?";
 ps = con.prepareStatement(query);

   ps.setInt(1, id);
   ps.setString(2,name);
   ps.setString(3,password);
   ps.setString(4,gender);
   ps.setString(5,email);
   ps.setString(6,mobile);
   ps.setString(7,date);
   ps.setString(8,city);
   ps.setString(9,address);
   ps.setString(10,age);
   ps.setString(11,school);
   ps.setString(12,income);
   ps.setString(13,occupation);
 
 ps.setInt(14, oldid);

 status = ps.executeUpdate() > 0;
 } catch (Exception e) {
 e.printStackTrace();
 } finally {
 try {
 if (ps != null) ps.close();
 if (con != null) con.close();
 } catch (Exception e) {
 e.printStackTrace();
 }
 }
 return status;
}
  
   
   
   public static List <Student> getAllStudents()
    {
     List <Student> studentList = new ArrayList<>();
     String sql = "Select * from student";
     Connection con = null;
     Statement st = null;
     ResultSet rs = null;
     try {
      con = getConnection();
      st = con.createStatement();
      rs = st.executeQuery(sql);
      while (rs.next())
      {
       studentList.add(new Student (rs.getInt("id"),rs.getString("name"),rs.getString("password"),rs.getString("gender"),rs.getString("email"),rs.getString("mobile"),rs.getString("date"),rs.getString("city"),rs.getString("address"),rs.getString("age"),rs.getString("school"),rs.getString("income"),rs.getString("occupation"),rs.getString("status")));
      }
     }
     catch (Exception e)
          {
        e.printStackTrace();
    }
     return studentList;
    }
   
   
   public static boolean DeleteStudent(int id){
  Connection con=null;
  PreparedStatement ps = null;
  boolean status = false;
 try {
 con=getConnection();
 String sql ="DELETE FROM student WHERE id=?";
 ps = con.prepareStatement(sql);
 ps.setInt(1,id);
 status = ps.executeUpdate() > 0;
} catch (Exception e) {
 e.printStackTrace();
 }
 return status;
  
}
   
   
   
   public static boolean approveStudent(int studentId, int sponserId) {
    boolean status = false;
    Connection con = null;
    PreparedStatement ps = null;

    try {
        con = getConnection();

        String query = "UPDATE student SET status='Approved', sponser_id=? WHERE id=?";
        ps = con.prepareStatement(query);

        ps.setInt(1, sponserId);
        ps.setInt(2, studentId);

        status = ps.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
    }

    return status;
}

}

