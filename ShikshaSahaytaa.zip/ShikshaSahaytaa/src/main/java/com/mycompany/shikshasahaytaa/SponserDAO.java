/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.shikshasahaytaa;


import static com.mycompany.shikshasahaytaa.StudentDAO.getConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author ASUS
 */
public class SponserDAO {
  public static final String url ="jdbc:mysql://localhost:3306/userdb";
  public static final String username="root";
  public static final String password="Mayuri@17";
  public static Connection getConnection(){
      Connection con =null;
    try
    {
      Class.forName("com.mysql.jdbc.Driver");
      con=DriverManager.getConnection(url,username,password);
    }
    catch(Exception e){
    e.printStackTrace();
    }        
    return con;
  }
  
public static boolean insertSponser( Sponser sponser ) {
   boolean status =false;
   Connection con =null;
   PreparedStatement ps = null;
  try
  {
   con=getConnection();
   String query="INSERT INTO sponser (name ,password ,Profession ,email ,mobile ,city ,address ) VALUES(?,?,?,?,?,?,?)";
   ps=con.prepareStatement(query);
   ps.setString(1,sponser.getName());
   ps.setString(2,sponser.getPassword());
   ps.setString(3,sponser.getProfession());
   ps.setString(4,sponser.getEmail());
   ps.setString(5,sponser.getMobile());
   ps.setString(6,sponser.getCity());
   ps.setString(7,sponser.getAddress());
   
   int rowInserted =ps.executeUpdate();
   status =rowInserted>0;
   con.close();
  }
  catch(Exception e)
  {
      
    e.printStackTrace();
  }
  
  return status;
  }



public static Sponser getSponserById(int id)
   {
       Sponser sponser=null;
       Connection con=null;
       try{
       con=getConnection();
       String query="select * from sponser where ID=?";
       PreparedStatement ps=con.prepareStatement(query);
       ps.setInt(1,id);
       
       ResultSet rs=ps.executeQuery();
       if(rs.next()){
         sponser=new Sponser(rs.getInt("id"),
         rs.getString("name"),
         rs.getString("password"), 
         rs.getString("Profession"),
         rs.getString("email"),
         rs.getString("mobile"),
         rs.getString("city"), 
         rs.getString("address"));
                 } 
                 
       }
         catch(Exception e){
           e.printStackTrace();
         }
         return sponser;
       }

   public static Sponser loginSponser(String name,String password)
   {
       Sponser sponser=null;
       Connection con=null;
       try{
       con=getConnection();
       String query="select  * from sponser where name=? and password=?";
       PreparedStatement ps=con.prepareStatement(query);
       ps.setString(1,name);
       ps.setString(2, password);
       ResultSet rs=ps.executeQuery();
       if(rs.next()){
         sponser=new Sponser(rs.getInt("id"),
         rs.getString("name"),
         rs.getString("password"), 
         rs.getString("Profession"),
         rs.getString("email"),
         rs.getString("mobile"),
         rs.getString("city"), 
         rs.getString("address"));
       }
       }
         catch(Exception e){
           e.printStackTrace();
         }
         return sponser;
       } 






   public static boolean updateSponser(int oldid, int id,String name, String password ,String Profession ,String email ,String mobile ,String city, String address )
   {
 Connection con = null;
 PreparedStatement ps = null;
 boolean status = false;
 try {
 con=getConnection();


 String query = "UPDATE sponser SET id=?, name=? ,password=? ,Profession=? ,email=? ,mobile=? ,city=? ,address=?  WHERE id=?";
 ps = con.prepareStatement(query);

   ps.setInt(1, id);
   ps.setString(2,name);
   ps.setString(3,password);
   ps.setString(4,Profession);
   ps.setString(5,email);
   ps.setString(6,mobile);
   ps.setString(7,city);
   ps.setString(8,address);
   ps.setInt(9, oldid);

 status = ps.executeUpdate() > 0;
 } catch (Exception e) {
 e.printStackTrace();
 } finally {
 try {
 if (ps != null) ps.close();
 if (con != null) con.close();
 } catch (Exception e) {
 e.printStackTrace();
 }
 }
 return status;
}
  
 public static List <Sponser> getAllSponser()
    {
     List <Sponser> sponserList = new ArrayList<>();
     String sql = "Select * from sponser";
     Connection con = null;
     Statement st = null;
     ResultSet rs = null;
     try {
      con = getConnection();
      st = con.createStatement();
      rs = st.executeQuery(sql);
      while (rs.next())
      {
       sponserList.add(new Sponser (rs.getInt("id"),rs.getString("name"),rs.getString("password"),rs.getString("Profession"),rs.getString("email"),rs.getString("mobile"),rs.getString("city"),rs.getString("address")));
      }
     }
     catch (Exception e)
          {
        e.printStackTrace();
    }
     return sponserList;
    }
 
 
 
 
 public static boolean DeleteSponser(int id){
  Connection con=null;
  PreparedStatement ps = null;
  boolean status = false;
 try {
 con=getConnection();
 String sql ="DELETE FROM sponser WHERE id=?";
 ps = con.prepareStatement(sql);
 ps.setInt(1,id);
 status = ps.executeUpdate() > 0;
} catch (Exception e) {
 e.printStackTrace();
 }
 return status;
  
}
 
 public static boolean updateStatus(int id, String status){
    boolean result = false;
    try{
        Connection con = getConnection();
        String query = "UPDATE student SET status=? WHERE id=?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, status);
        ps.setInt(2, id);

        result = ps.executeUpdate() > 0;
        con.close();
    }catch(Exception e){
        e.printStackTrace();
    }
    return result;
}
 
 
}

