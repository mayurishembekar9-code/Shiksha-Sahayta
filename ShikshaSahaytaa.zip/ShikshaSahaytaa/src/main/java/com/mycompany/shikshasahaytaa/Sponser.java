/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.shikshasahaytaa;

import java.io.Serializable;



/**
 *
 * @author ASUS
 */
public class Sponser implements Serializable
{
    private String name;
    private String password;
    private String Profession;
    private String email;
    private String mobile;     
    private String city;
    private String address;
    private int id;
public Sponser()
{

}

public Sponser(String name, String password ,String Profession,String email ,String mobile , String city ,String address )
{
  this.name=name;
  this.password=password;
  this.Profession=Profession;
  this.email=email;
  this.mobile=mobile;
  this.city=city;
  this.address=address;
  
}


        
public Sponser(int id ,String name, String password ,String Profession,String email ,String mobile ,String city, String address )
{
  this.id=id;
  this.name=name;
  this.password=password;
  this.Profession=Profession;
  this.email=email;
  this.mobile=mobile;
  this.city=city;
  this.address=address;
  
}
public String getName()
{
return name;
}
public String getPassword()
{
return password;
}
public String getProfession()
{
return Profession;
}
public String getEmail()
{
return email;
}
public String getMobile()
{
return mobile;
}
public String getCity()
{
return city;
}
public String getAddress()
{
return address;
}

public int getID()
{
return id;
}

}