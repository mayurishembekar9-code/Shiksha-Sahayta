<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update Successful</title>

<style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body{
        height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    }

    .card{
        background: #1e1e1e;
        padding: 40px;
        border-radius: 15px;
        text-align:center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.6);
        color:#f1f1f1;
        width:360px;
    }

    .icon{
        font-size:50px;
        margin-bottom:15px;
    }

    h1{
        color:#00ffcc;
        margin-bottom:10px;
    }

    p{
        font-size:15px;
        margin-bottom:25px;
        color:#ccc;
    }

    .btn{
        display:inline-block;
        padding:10px 20px;
        margin:5px;
        text-decoration:none;
        color:white;
        border-radius:8px;
        background: linear-gradient(135deg, #00cc99, #006666);
        transition:0.3s;
    }

    .btn:hover{
        transform: scale(1.05);
    }

    .home{
        background: linear-gradient(135deg, #ff4d4d, #990000);
    }

</style>

</head>

<body>

<div class="card">
    
    <div class="icon">✅</div>

    <h1>Update Successful</h1>
    <p>Your profile has been updated successfully.</p>

    <a href="SponserDashboard.jsp" class="btn">Go to Dashboard</a>
    <a href="HomePage.html" class="btn home">Home</a>

</div>

</body>
</html>