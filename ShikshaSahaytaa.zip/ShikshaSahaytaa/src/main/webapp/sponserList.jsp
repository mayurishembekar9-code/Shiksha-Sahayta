<%@page import="com.mycompany.shikshasahaytaa.Sponser"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sponsor List</title>

<style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body{
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        color:white;
        padding:20px;
    }

    h1{
        text-align:center;
        margin-bottom:20px;
        color:#00ffcc;
    }

    .table-container{
        overflow-x:auto;
    }

    table{
        width:100%;
        border-collapse: collapse;
        background: #1e1e1e;
        border-radius:10px;
        overflow:hidden;
    }

    th, td{
        padding:10px;
        text-align:center;
        font-size:14px;
    }

    th{
        background:#00cc99;
        color:#000;
    }

    tr:nth-child(even){
        background:#2c2c2c;
    }

    tr:hover{
        background:#3a3a3a;
    }

    .btn{
        padding:6px 10px;
        border:none;
        border-radius:6px;
        color:white;
        cursor:pointer;
        text-decoration:none;
        font-size:12px;
    }

    .approve{
        background: #28a745;
    }

    .delete{
        background: #ff4444;
    }

    .delete:hover{
        background: #cc0000;
    }

    .back{
        display:inline-block;
        margin-bottom:15px;
        padding:8px 12px;
        background:#00cc99;
        color:black;
        text-decoration:none;
        border-radius:6px;
    }
</style>
</head>

<body>

<a href="AdminDashboard.jsp" class="back">⬅ Back to Dashboard</a>

<h1>All Registered Sponsors</h1>

<div class="table-container">

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Password</th>
        <th>Profession</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>City</th>
        <th>Address</th>
        <th>Action</th>
    </tr>

<%
    List<Sponser> sponserList = (List<Sponser>) request.getAttribute("sponserList");

    if(sponserList != null && !sponserList.isEmpty()){
        for(Sponser u : sponserList){
%>

    <tr>
        <td><%=u.getID()%></td>
        <td><%=u.getName()%></td>
        <td><%=u.getPassword()%></td>
        <td><%=u.getProfession()%></td>
        <td><%=u.getEmail()%></td>
        <td><%=u.getMobile()%></td>
        <td><%=u.getCity()%></td>
        <td><%=u.getAddress()%></td>

        <td>
            <a href="ApproveSponserServlet?id=<%=u.getID()%>" class="btn approve">Approve</a>

            <a href="DeleteSponserServlet?id=<%=u.getID()%>" 
               class="btn delete"
               onclick="return confirm('Do you really want to delete this sponsor?');">
               Delete
            </a>
        </td>
    </tr>

<%
        }
    } else {
%>

    <tr>
        <td colspan="9">No Sponsors Found</td>
    </tr>

<%
    }
%>

</table>
</div>

</body>
</html>