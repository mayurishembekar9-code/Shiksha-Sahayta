<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Success</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f8ff;
        text-align: center;
        padding-top: 100px;
    }
    .box {
        background-color: #ffffff;
        border: 2px solid #4CAF50;
        display: inline-block;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }
    h2 {
        color: #4CAF50;
    }
    a {
        text-decoration: none;
        color: white;
        background-color: #4CAF50;
        padding: 10px 20px;
        border-radius: 5px;
    }
    a:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="box">
    <h2>Data Inserted Successfully!</h2>
    <p>Your record has been saved in the database.</p>
    <br>
    <a href="login.html">Go Back</a>
</div>

</body>
</html>