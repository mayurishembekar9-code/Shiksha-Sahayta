<%@page import="com.mycompany.shikshasahaytaa.Sponser"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sponsor Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #f1f1f1;
        }

        .container {
            background: #1e1e1e;
            padding: 30px;
            border-radius: 15px;
            width: 420px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }

        h1 {
            text-align: center;
            color: #00ffcc;
        }

        h2 {
            color: #00cc99;
            border-bottom: 2px solid #00cc99;
            padding-bottom: 5px;
        }

        p {
            margin: 8px 0;
            font-size: 14px;
        }

        .label {
            font-weight: bold;
            color: #00ffcc;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            margin-top: 15px;
            text-decoration: none;
            color: white;
            background: linear-gradient(135deg, #00cc99, #006666);
            border-radius: 8px;
            transition: 0.3s;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .logout {
            background: linear-gradient(135deg, #ff4d4d, #990000);
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
    </style>
</head>

<body>

<%
    Sponser sponser =(Sponser)session.getAttribute("sponser");
    if(sponser==null){
        response.sendRedirect("SponserLogin.jsp");
        return;
    }
%>

<div class="container">
    <h1>Welcome, <%=sponser.getName()%></h1>

    <h2>Submitted Details</h2>

    <p><span class="label">ID:</span> <%=sponser.getID()%></p>
    <!-- ⚠️ Hide password -->
    <p><span class="label">Password:</span> ******</p>
    <p><span class="label">Profession:</span> <%=sponser.getProfession()%></p>
    <p><span class="label">Email:</span> <%=sponser.getEmail()%></p>
    <p><span class="label">Mobile:</span> <%=sponser.getMobile()%></p>
    <p><span class="label">City:</span> <%=sponser.getCity()%></p>
    <p><span class="label">Address:</span> <%=sponser.getAddress()%></p>

    <div class="button-container">
        <a href="SponserUpdateController?id=<%=sponser.getID()%>" class="btn">Update</a>
        <a href="StudentListServlet" class="btn">View Students</a>
        <a href="LogoutServlet" class="btn logout">Logout</a>
    </div>
</div>

</body>
</html>