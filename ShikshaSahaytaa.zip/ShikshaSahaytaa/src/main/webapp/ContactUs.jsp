<%-- 
    Document   : ContactUs
    Created on : Mar 25, 2026, 2:07:55 AM
    Author     : ASUS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
     <style>
            
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
  font-family: Arial;
  margin: 0;
  background: #f5f5f5;
}

/* Header */
header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
}

/* Top navigation bar */
.navbar {
  display: flex;
  background-color: #333;
}

/* Navigation bar links */
.navbar a {
  color: white;
  padding: 14px 20px;
  text-decoration: none;
  text-align: center;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}


/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .container, .navbar {   
    flex-direction: column;
  }
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: sans-serif;
}
.container{
 padding:50px;
 text-align: center;
 align-items: center;
 font-size: 18px;
 }       
        </style>
    </head>
    <body>
        <div style="background:yellow;padding:5px;text-align:center;">

</div>

<!-- Header -->
<header>
    <h1><u>SHIKSHYA SAHAYTA - Child Education Support System</u></h1>
    
</header>

<!-- Navigation Bar -->
<div class="navbar">
  <a href="HomePage.html">Home</a>
  <a href="AboutUs.html">About Us</a>
  <a href="ContactUs.html">Contact Us</a>
  <a href="login.html">login</a>
</div>

<div class="container">
            <h1>Your Query is submitted successfully</h1>
</div>

    </body>
</html>
