<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Success</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #3cb371, #2e8b57);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        h2 {
            color: green;
        }

        .btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 15px;
            text-decoration: none;
            background: #2e8b57;
            color: white;
            border-radius: 5px;
        }

        .btn:hover {
            background: #3cb371;
        }
    </style>
</head>

<body>

<div class="box">
    <h2>✅ Data Updated Successfully!</h2>
    <p>Your details have been updated.</p>

    <a href="StudentDashboard.jsp" class="btn">Go to Dashboard</a>
</div>

</body>
</html>