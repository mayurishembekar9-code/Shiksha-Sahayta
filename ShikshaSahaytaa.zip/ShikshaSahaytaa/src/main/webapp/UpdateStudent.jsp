<%@page import="com.mycompany.shikshasahaytaa.Student"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #3cb371, #2e8b57, #66cdaa);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            width: 450px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #2e8b57;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #2e8b57;
            display: block;
            margin-top: 10px;
        }

        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        textarea {
            resize: none;
        }

        .radio-group {
            margin-top: 5px;
        }

        .radio-group input {
            width: auto;
            margin-right: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #3cb371, #2e8b57);
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn:hover {
            transform: scale(1.05);
        }

    </style>
</head>

<body>

<%
    Student student = (Student) request.getAttribute("student");
    if (student != null) {
%>

<div class="container">
    <h2>Update Student Details</h2>

    <form action="SaveStudentUpdateController">

        <input type="hidden" name="oldid" value="<%= student.getID() %>">

        <label>ID</label>
        <input type="text" name="id" value="<%= student.getID() %>">

        <label>Name</label>
        <input type="text" name="name" value="<%= student.getName() %>">

        <label>Password</label>
        <input type="password" name="password" value="<%= student.getPassword() %>">

        <label>Gender</label>
        <div class="radio-group">
            <input type="radio" name="gender" value="Male" <%= student.getGender().equals("Male") ? "checked" : "" %>> Male
            <input type="radio" name="gender" value="Female" <%= student.getGender().equals("Female") ? "checked" : "" %>> Female
        </div>

        <label>Email</label>
        <input type="email" name="email" value="<%=student.getEmail()%>">

        <label>Mobile</label>
        <input type="text" name="mobile" value="<%=student.getMobile()%>">

        <label>Date</label>
        <input type="date" name="date" value="<%=student.getDate()%>">

        <label>City</label>
        <select name="city">
            <option value="-1"<%=student.getCity().equals("-1") ? "selected" : "" %>>Select</option>
            <option value="Amravti"<%= student.getCity().equals("Amravti") ? "selected" : "" %>>Amravti</option>
            <option value="Nagpur"<%= student.getCity().equals("Nagpur") ? "selected" : "" %>>Nagpur</option>
            <option value="Pune"<%= student.getCity().equals("Pune") ? "selected" : "" %>>Pune</option>
            <option value="Delhi"<%= student.getCity().equals("Delhi") ? "selected" : "" %>>Delhi</option>
            <option value="Mumbai"<%= student.getCity().equals("Mumbai") ? "selected" : "" %>>Mumbai</option>
            <option value="Kolkata"<%= student.getCity().equals("Kolkata") ? "selected" : "" %>>Kolkata</option>
            <option value="Chennai"<%= student.getCity().equals("Chennai") ? "selected" : "" %>>Chennai</option>
            <option value="Jaipur"<%= student.getCity().equals("Jaipur") ? "selected" : "" %>>Jaipur</option>
        </select>

        <label>Address</label>
        <textarea name="address" rows="3"><%=student.getAddress()%></textarea>

        <label>Age</label>
        <input type="text" name="age" value="<%=student.getAge()%>">

        <label>School</label>
        <input type="text" name="school" value="<%=student.getSchool()%>">

        <label>Income</label>
        <select name="income">
            <option value="-1"<%=student.getIncome().equals("-1") ? "selected" : "" %>>Select</option>
            <option value="Below 100000"<%= student.getIncome().equals("Below 100000") ? "selected" : "" %>>Below 100000</option>
            <option value="Above 100000"<%= student.getIncome().equals("Above 100000") ? "selected" : "" %>>Above 100000</option>
        </select>

        <label>Occupation</label>
        <input type="text" name="occupation" value="<%=student.getOccupation()%>">

        <button type="submit" class="btn">Update</button>

    </form>
</div>

<% } else { %>
<p style="color:white;">Student not found.</p>
<% } %>

</body>
</html>