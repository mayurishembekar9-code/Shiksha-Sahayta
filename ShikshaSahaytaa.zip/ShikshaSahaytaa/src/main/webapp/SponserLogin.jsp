<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sponsor Login</title>

<style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body{
        height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
    }

    .container{
        width: 350px;
        padding: 35px;
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(12px);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.5);
        color: #e0f7fa;
    }

    h2{
        text-align:center;
        margin-bottom:20px;
        font-weight:600;
        color: #00ffcc;
    }

    form{
        display:flex;
        flex-direction:column;
    }

    .input-box{
        margin-bottom:18px;
        display:flex;
        flex-direction:column;
    }

    .input-box label{
        margin-bottom:6px;
        font-size:14px;
        color: #b2dfdb;
    }

    .input-box input{
        padding:10px;
        border:none;
        border-radius:8px;
        outline:none;
        background: rgba(255,255,255,0.15);
        color:white;
        font-size:14px;
        transition:0.3s;
    }

    .input-box input::placeholder{
        color:#ccc;
    }

    .input-box input:focus{
        background: rgba(255,255,255,0.25);
        transform: scale(1.03);
        box-shadow: 0 0 8px #00ffcc;
    }

    .btn{
        margin-top:10px;
        padding:12px;
        border:none;
        border-radius:8px;
        background: linear-gradient(135deg, #00cc99, #006666);
        color:white;
        font-size:16px;
        cursor:pointer;
        transition:0.3s;
    }

    .btn:hover{
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.5);
    }

    .footer{
        text-align:center;
        margin-top:15px;
        font-size:13px;
        color:#ccc;
    }

    .footer a{
        color:#00ffcc;
        text-decoration:none;
    }

    .footer a:hover{
        text-decoration:underline;
    }

</style>

</head>

<body>

<div class="container">
    <form action="SponserLoginServlet" method="post">
        <h2> Sponsor Login</h2>

        <div class="input-box">
            <label>Enter Name</label>
            <input type="text" name="name" placeholder="Enter your name" required>
        </div>

        <div class="input-box">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password" required>
        </div>

        <input type="submit" class="btn" value="Login">

        <div class="footer">
            <p>Don't have an account? <a href="SponserRegisteration.html">Sign up</a></p>
        </div>
    </form>
</div>

</body>
</html>