<%@page import="com.mycompany.shikshasahaytaa.Sponser"%>
<%@page import="com.mycompany.shikshasahaytaa.SponserDAO"%>
<%@page import="com.mycompany.shikshasahaytaa.StudentDAO"%>
<%@page import="com.mycompany.shikshasahaytaa.Student"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Dashboard</title>

<style>

/* Background */
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #3cb371, #2e8b57, #66cdaa);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* Main Card */
.container {
    background: white;
    padding: 30px;
    border-radius: 15px;
    width: 420px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

/* Headings */
h1 {
    text-align: center;
    color: #2e8b57;
}

h2 {
    color: #3cb371;
    border-bottom: 2px solid #3cb371;
    padding-bottom: 5px;
    margin-top: 20px;
}

/* Text */
p {
    margin: 6px 0;
    font-size: 14px;
}

.label {
    font-weight: bold;
    color: #2e8b57;
}

/* Buttons */
.btn {
    display: inline-block;
    padding: 10px 15px;
    margin-top: 15px;
    text-decoration: none;
    color: white;
    background: linear-gradient(135deg, #3cb371, #2e8b57);
    border-radius: 8px;
    transition: 0.3s;
    text-align: center;
}

.btn:hover {
    transform: scale(1.05);
}

.logout {
    background: linear-gradient(135deg, #ff6b6b, #c0392b);
}

.button-container {
    display: flex;
    justify-content: space-between;
}

/* STATUS CARD */
.status-card {
    margin-top: 20px;
    padding: 15px;
    border-radius: 10px;
    background: #f9f9f9;
}

/* Status Colors */
.approved { color: green; font-weight: bold; }
.rejected { color: red; font-weight: bold; }
.pending { color: orange; font-weight: bold; }

/* Sponsor Box */
.sponsor-box {
    margin-top: 12px;
    padding: 12px;
    background: #e6fff2;
    border-left: 5px solid #2ecc71;
    border-radius: 8px;
}

/* Waiting */
.waiting {
    margin-top: 12px;
    padding: 10px;
    background: #fff3cd;
    border-left: 5px solid #ffc107;
    border-radius: 8px;
    font-weight: bold;
}

/* Back Button */
.back-btn {
    margin-top: 10px;
    cursor: pointer;
    color: #2e8b57;
    font-weight: bold;
}

</style>
</head>

<body>

<%
    Student student = (Student)session.getAttribute("student");
    if(student == null){
        response.sendRedirect("StudentLogin.jsp");
        return;
    }

    Student s = StudentDAO.getStudentById(student.getID());

    String status = s.getStatus();
    if(status == null){
        status = "Pending";
    }

    int sponserId = s.getID();  // ✅ FIXED
    Sponser sp = null;

    if(sponserId > 0){
        sp = SponserDAO.getSponserById(sponserId);
    }
%>

<div class="container">

    <h1>Welcome, <%=student.getName()%></h1>

    <h2>Student Details</h2>

    <p><span class="label">ID:</span> <%=student.getID()%></p>
    <p><span class="label">Password:</span> ******</p>
    <p><span class="label">Gender:</span> <%=student.getGender()%></p>
    <p><span class="label">Email:</span> <%=student.getEmail()%></p>
    <p><span class="label">Mobile:</span> <%=student.getMobile()%></p>
    <p><span class="label">Date:</span> <%=student.getDate()%></p>
    <p><span class="label">City:</span> <%=student.getCity()%></p>
    <p><span class="label">Address:</span> <%=student.getAddress()%></p>
    <p><span class="label">Age:</span> <%=student.getAge()%></p>
    <p><span class="label">School:</span> <%=student.getSchool()%></p>
    <p><span class="label">Income:</span> <%=student.getIncome()%></p>
    <p><span class="label">Occupation:</span> <%=student.getOccupation()%></p>

    <!-- ✅ STATUS + SPONSOR -->
    <div class="status-card">

        <h2>Scholarship Status</h2>

        <p>
            <span class="label">Status:</span>

            <% if(status.equalsIgnoreCase("Approved")) { %>
                <span class="approved">Approved ✅</span>
            <% } else if(status.equalsIgnoreCase("Rejected")) { %>
                <span class="rejected">Rejected ❌</span>
            <% } else { %>
                <span class="pending">Pending ⏳</span>
            <% } %>
        </p>

        <% if(status.equalsIgnoreCase("Approved") && sp != null){ %>

            <div class="sponsor-box">
                <h3>Sponsor Details</h3>
                <p><b>Name:</b> <%= sp.getName() %></p>
                <p><b>Email:</b> <%= sp.getEmail() %></p>
                <p><b>Contact:</b> <%= sp.getMobile() %></p>
                <p><b>City:</b> <%= sp.getCity() %></p>
            </div>

        <% } else { %>

            <div class="waiting">
                ⏳ Waiting for sponsor approval...
            </div>

        <% } %>

        <a href="StudentDashboard.jsp" class="btn">Refresh</a>

    </div>

    <!-- BUTTONS -->
    <div class="button-container">
        <a href="StudentUpdateController?id=<%=student.getID()%>" class="btn">Update</a>
        <a href="LogoutServlet" class="btn logout">Logout</a>
    </div>

    <div class="back-btn" onclick="history.back()">⬅ Back</div>

</div>

</body>
</html>