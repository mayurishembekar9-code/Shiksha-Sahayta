<%-- 
    Document   : LoginError
    Created on : Mar 30, 2026, 7:53:53 PM
    Author     : ASUS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@page session="true"%>
       <h2>Invalid username or password</h2>
       <a href="AdminLogin.html">Try Again</a>
       <%
        session.invalidate();
       %>
    </body>
</html>
