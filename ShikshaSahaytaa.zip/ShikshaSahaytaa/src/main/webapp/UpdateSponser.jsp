<%@page import="com.mycompany.shikshasahaytaa.Sponser"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update Sponsor</title>

<style>
    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body{
        height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        background: linear-gradient(135deg, #141e30, #243b55);
    }

    .container{
        width: 420px;
        padding: 30px;
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(10px);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.6);
        color: #e0f7fa;
    }

    h2{
        text-align:center;
        margin-bottom:20px;
        color:#00e6ac;
    }

    label{
        font-size:14px;
        margin-top:10px;
        display:block;
        color:#b2dfdb;
    }

    input, select, textarea{
        width:100%;
        padding:10px;
        margin-top:5px;
        border:none;
        border-radius:8px;
        background: rgba(255,255,255,0.15);
        color:white;
        font-size:14px;
        outline:none;
        transition:0.3s;
    }

    input:focus, select:focus, textarea:focus{
        background: rgba(255,255,255,0.25);
        box-shadow: 0 0 8px #00e6ac;
    }

    textarea{
        resize:none;
    }

    .btn{
        margin-top:20px;
        padding:12px;
        width:100%;
        border:none;
        border-radius:8px;
        background: linear-gradient(135deg, #00cc99, #006666);
        color:white;
        font-size:16px;
        cursor:pointer;
        transition:0.3s;
    }

    .btn:hover{
        transform: scale(1.05);
    }

</style>

</head>

<body>

<%
    Sponser sponser = (Sponser) request.getAttribute("sponser");
    if (sponser != null) {
%>

<div class="container">
    <h2>Update Sponsor Details</h2>

    <form action="SaveSponserUpdateController" method="post">

        <input type="hidden" name="oldid" value="<%= sponser.getID() %>">

        <label>ID</label>
        <input type="text" name="id" value="<%= sponser.getID() %>">

        <label>Name</label>
        <input type="text" name="name" value="<%= sponser.getName() %>">

        <label>Password</label>
        <input type="password" name="password" value="<%= sponser.getPassword() %>">

        <label>Profession</label>
        <select name="Profession">
            <option value="Doctor" <%= sponser.getProfession().equals("Doctor") ? "selected" : "" %>>Doctor</option>
            <option value="Engineer" <%= sponser.getProfession().equals("Engineer") ? "selected" : "" %>>Engineer</option>
            <option value="Teacher" <%= sponser.getProfession().equals("Teacher") ? "selected" : "" %>>Teacher</option>
            <option value="Lawyer" <%= sponser.getProfession().equals("Lawyer") ? "selected" : "" %>>Lawyer</option>
            <option value="Police Officer" <%= sponser.getProfession().equals("Police Officer") ? "selected" : "" %>>Police Officer</option>
            <option value="Accountant" <%= sponser.getProfession().equals("Accountant") ? "selected" : "" %>>Accountant</option>
            <option value="Software Developer" <%= sponser.getProfession().equals("Software Developer") ? "selected" : "" %>>Software Developer</option>
            <option value="Farming" <%= sponser.getProfession().equals("Farming") ? "selected" : "" %>>Farming</option>
        </select>

        <label>Email</label>
        <input type="text" name="email" value="<%=sponser.getEmail()%>">

        <label>Mobile</label>
        <input type="text" name="mobile" value="<%=sponser.getMobile()%>">

        <label>City</label>
        <select name="city">
            <option value="Amravti"<%= sponser.getCity().equals("Amravti") ? "selected" : "" %>>Amravti</option>
            <option value="Nagpur"<%= sponser.getCity().equals("Nagpur") ? "selected" : "" %>>Nagpur</option>
            <option value="Pune"<%= sponser.getCity().equals("Pune") ? "selected" : "" %>>Pune</option>
            <option value="Delhi"<%= sponser.getCity().equals("Delhi") ? "selected" : "" %>>Delhi</option>
            <option value="Mumbai"<%= sponser.getCity().equals("Mumbai") ? "selected" : "" %>>Mumbai</option>
            <option value="Kolkata"<%= sponser.getCity().equals("Kolkata") ? "selected" : "" %>>Kolkata</option>
            <option value="Chennai"<%= sponser.getCity().equals("Chennai") ? "selected" : "" %>>Chennai</option>
            <option value="Jaipur"<%= sponser.getCity().equals("Jaipur") ? "selected" : "" %>>Jaipur</option>
        </select>

        <label>Address</label>
        <textarea name="address" rows="3"><%=sponser.getAddress()%></textarea>

        <button type="submit" class="btn">Update</button>

    </form>
</div>

<% } else { %>
<p style="color:white;">Sponsor not found.</p>
<% } %>

</body>
</html>