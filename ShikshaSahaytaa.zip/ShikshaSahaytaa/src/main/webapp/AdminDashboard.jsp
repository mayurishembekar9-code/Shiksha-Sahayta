<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Admin Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #020617, #1e3a8a);
            height: 100vh;
        }

        .main-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Glass Box (Light Theme) */
        .glass-box {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-radius: 20px;
            padding: 40px;
            width: 85%;
            max-width: 900px;

            /* Soft Neon Glow */
            box-shadow: 
                0 0 15px rgba(0, 140, 255, 0.3),
                0 0 30px rgba(0, 140, 255, 0.2);

            border: 1px solid rgba(0, 140, 255, 0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
            color: #0d47a1;
            text-shadow: 0 0 6px rgba(0,140,255,0.4);
        }

        .subtitle {
            text-align: center;
            margin-bottom: 30px;
            color: #1565c0;
        }

        .cards {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        .card {
            background: rgba(255, 255, 255, 0.7);
            border-radius: 15px;
            padding: 25px;
            width: 220px;
            text-align: center;

            border: 1px solid rgba(0, 140, 255, 0.3);

            /* Light Neon Glow */
            box-shadow: 0 0 12px rgba(0,140,255,0.25);

            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-8px) scale(1.04);
            box-shadow: 
                0 0 20px rgba(0,140,255,0.5),
                0 0 35px rgba(0,140,255,0.3);
        }

        .card h2 {
            color: #0d47a1;
        }

        .card p {
            font-size: 14px;
            color: #444;
            margin-bottom: 20px;
        }

        .btn {
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 8px;
            background: transparent;
            color: #0d47a1;
            font-weight: bold;
            border: 1px solid #0d47a1;

            box-shadow: 0 0 8px rgba(0,140,255,0.3);
            transition: 0.3s;
        }

        .btn:hover {
            background: #0d47a1;
            color: white;
            box-shadow: 0 0 20px rgba(0,140,255,0.6);
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #1565c0;
        }
    </style>
</head>

<body>

    <div class="main-container">
        <div class="glass-box">
            
            <h1>Admin Dashboard</h1>
            <div class="subtitle">Welcome to the Control Panel</div>

            <div class="cards">
                
                <div class="card">
                    <h2>Students</h2>
                    <p>Manage all student records efficiently.</p>
                    <a href="StudentList2Servlet" class="btn">View Students</a>
                </div>

                <div class="card">
                    <h2>Sponsors</h2>
                    <p>Access and manage sponsor information.</p>
                    <a href="SponserListServlet" class="btn">View Sponsors</a>
                </div>

            </div>

            <div class="footer">
                Logged in as Admin 
            </div>

        </div>
    </div>

</body>
</html>