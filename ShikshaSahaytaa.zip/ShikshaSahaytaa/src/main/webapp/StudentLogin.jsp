<%-- 
    Document   : StudentLogin
    Created on : Mar 27, 2026, 2:38:56 PM
    Author     : ASUS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
body {
    margin: 0;
    padding: 0;
    background: linear-gradient(to right, #20c997, #28a745);
    font-family: 'Segoe UI', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Container */
.container {
    background: #ffffff;
    padding: 40px 30px;
    width: 350px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    border-radius: 12px;
    text-align: center;
}

/* Heading */
h2 {
    margin-bottom: 20px;
    font-weight: 600;
    color: #333;
}

/* Form */
form {
    display: flex;
    flex-direction: column;
}

/* Input group */
.name {
    display: flex;
    flex-direction: column;
    margin-bottom: 15px;
    text-align: left;
}

.name label {
    margin-bottom: 6px;
    font-weight: 500;
    color: #555;
}

/* Inputs */
.name input {
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 25px;
    font-size: 14px;
    outline: none;
    transition: 0.3s;
}

/* Focus effect */
.name input:focus {
    border-color: #20c997;
    box-shadow: 0 0 5px rgba(32, 201, 151, 0.5);
}

/* Button */
input[type="submit"] {
    margin-top: 10px;
    padding: 12px;
    border: none;
    border-radius: 25px;
    background: #20c997;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
    font-weight: 600;
}

input[type="submit"]:hover {
    background: #17a589;
}

/* Optional small text */
.extra {
    margin-top: 10px;
    font-size: 13px;
    color: #666;
}

.extra a {
    color: #20c997;
    text-decoration: none;
}

.extra a:hover {
    text-decoration: underline;
}
</style>

</head>

<body>

<div class="container">
    
    <form action="StudentLoginServlet" method="post">
        
        <h2>Student Login</h2> 
        
        <div class="name">
            <label>Enter Name</label>
            <input type="text" name="name" placeholder="Enter your name" required />
        </div>

        <div class="name">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password" required />
        </div>

        <input type="submit" value="Login"> 
        
        <!-- Optional -->
        <div class="extra">
            <p>Don't have an account? <a href="StudentRegisteration.html">Sign up</a></p>
        </div>

    </form>

</div>

</body> 
</html>
